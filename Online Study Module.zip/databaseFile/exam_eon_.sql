-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2022 at 03:42 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam(eon)`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `adminID` varchar(10) NOT NULL,
  `adminNAME` varchar(100) NOT NULL,
  `adminGENDER` varchar(10) NOT NULL,
  `adminEMAIL` varchar(100) NOT NULL,
  `adminPASSWORD` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminID`, `adminNAME`, `adminGENDER`, `adminEMAIL`, `adminPASSWORD`) VALUES
(1, 'MS001', 'Soumalya Mondal', 'Male', 'iamsoumalya007@hotmail.com', '$2y$10$Az9L/DlfOzahRyB2pVKw4.VKZCMX22flrFTVg9z/Z5.KSIDQBVLe6');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(10) NOT NULL,
  `courseID` varchar(15) NOT NULL,
  `courseNAME` varchar(100) NOT NULL,
  `courseTHUMBNIL` varchar(100) NOT NULL,
  `courseDESCRIPTION` text NOT NULL,
  `courseCreateDATE` varchar(15) NOT NULL,
  `courseCreateNAME` varchar(100) NOT NULL,
  `courseCreateID` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `courseID`, `courseNAME`, `courseTHUMBNIL`, `courseDESCRIPTION`, `courseCreateDATE`, `courseCreateNAME`, `courseCreateID`) VALUES
(1, 'PYT001', 'Python Beginner Guide', 'asset/CourseThumbnilPicture/PYT001.png', 'Python is a high-level, interpreted, general-purpose programming language. Its design philosophy emphasizes code readability with the use of significant indentation. Python is dynamically-typed and garbage-collected. It supports multiple programming paradigms, including structured (particularly procedural), object-oriented and functional programming. It is often described as a \"batteries included\" language due to its comprehensive standard library. Python consistently ranks as one of the most popular programming languages.', '28-06-2022', 'Soumalya Mondal', 'MS001'),
(2, 'HTM001', 'HTML & CSS Beginner Guide', 'asset/CourseThumbnilPicture/HTM001.png', 'The HyperText Markup Language or HTML is the standard markup language for documents designed to be displayed in a web browser. It can be assisted by technologies such as Cascading Style Sheets (CSS) and scripting languages such as JavaScript. Web browsers receive HTML documents from a web server or from local storage and render the documents into multimedia web pages. HTML describes the structure of a web page semantically and originally included cues for the appearance of the document. Cascading Style Sheets (CSS) is a style sheet language used for describing the presentation of a document written in a markup language such as HTML or XML (including XML dialects such as SVG, MathML or XHTML). CSS is a cornerstone technology of the World Wide Web, alongside HTML and JavaScript. The name cascading comes from the specified priority scheme to determine which style rule applies if more than one rule matches a particular element. This cascading priority scheme is predictable.', '28-06-2022', 'Soumalya Mondal', 'MS001'),
(3, 'PHP001', 'PHP Server Site Scripting Language', 'asset/CourseThumbnilPicture/PHP001.png', 'PHP is a general-purpose scripting language geared toward web development. It was originally created by Danish-Canadian programmer Rasmus Lerdorf in 1994. The PHP reference implementation is now produced by The PHP Group. PHP originally stood for Personal Home Page, but it now stands for the recursive initialism PHP: Hypertext Preprocessor. The standard PHP interpreter, powered by the Zend Engine, is free software released under the PHP License. PHP has been widely ported and can be deployed on most web servers on a variety of operating systems and platforms.', '28-06-2022', 'Soumalya Mondal', 'MS001');

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `id` int(10) NOT NULL,
  `moduleID` varchar(20) NOT NULL,
  `courseID` varchar(15) NOT NULL,
  `moduleNAME` varchar(100) NOT NULL,
  `moduleTHUMBNIL` varchar(100) NOT NULL,
  `moduleVideoID` varchar(20) NOT NULL,
  `moduleDESCRIPTION` text NOT NULL,
  `moduleCreateDATE` varchar(15) NOT NULL,
  `moduleCreateNAME` varchar(100) NOT NULL,
  `moduleCreateID` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`id`, `moduleID`, `courseID`, `moduleNAME`, `moduleTHUMBNIL`, `moduleVideoID`, `moduleDESCRIPTION`, `moduleCreateDATE`, `moduleCreateNAME`, `moduleCreateID`) VALUES
(1, 'PHP001-0001', 'PHP001', 'Connect Database With PHP', 'asset/ModuleThumbnilPicture/PHP001-0001.png', 'rkcq0Cv9Vp8', 'Database Connection with php by XAMPP software', '30-06-2022', 'MS001', 'Soumalya Mondal'),
(2, 'PHP001-0002', 'PHP001', 'Forum Website Using PHP', 'asset/ModuleThumbnilPicture/PHP001-0002.png', '6RGrhOWlrtg', 'Making Forum Website using PHP', '30-06-2022', 'MS001', 'Soumalya Mondal'),
(3, 'PYT001-0001', 'PYT001', 'type() Function', 'asset/ModuleThumbnilPicture/PYT001-0001.png', 'nm7NybyCKRs', 'Where to use and how to use type() function in PYTHON', '30-06-2022', 'MS001', 'Soumalya Mondal'),
(4, 'HTM001-0001', 'HTM001', 'CSS Variables', 'asset/ModuleThumbnilPicture/HTM001-0001.png', 'hfcBoCn8fyE', 'How to use CSS variables', '30-06-2022', 'MS001', 'Soumalya Mondal');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `userNAME` varchar(100) NOT NULL,
  `userEMAIL` varchar(100) NOT NULL,
  `userSCHOOL` varchar(500) NOT NULL,
  `userBATCH` varchar(20) NOT NULL,
  `userCREATE` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(10) NOT NULL,
  `studentID` varchar(10) NOT NULL,
  `studentFirstNAME` varchar(50) NOT NULL,
  `studentLastNAME` varchar(50) NOT NULL,
  `studentPICTURE` varchar(100) NOT NULL,
  `studentEMAIL` varchar(100) NOT NULL,
  `studentGuardianPHONE` varchar(15) NOT NULL,
  `studentPHONE` varchar(15) NOT NULL,
  `studentDOB` varchar(20) NOT NULL,
  `studentGENDER` varchar(10) NOT NULL,
  `studentADDRESS` text NOT NULL,
  `studentSTATE` varchar(50) NOT NULL,
  `studentPINCODE` varchar(6) NOT NULL,
  `studentSCHOOL` text NOT NULL,
  `studentBOARD` text NOT NULL,
  `studentCLASS` varchar(20) NOT NULL,
  `studentPASSWORD` varchar(255) NOT NULL,
  `studentCONCERN` varchar(10) NOT NULL,
  `studentPRIVACY` varchar(10) NOT NULL,
  `studentCreateTIME` varchar(20) NOT NULL,
  `studentCreateDATE` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `studentID`, `studentFirstNAME`, `studentLastNAME`, `studentPICTURE`, `studentEMAIL`, `studentGuardianPHONE`, `studentPHONE`, `studentDOB`, `studentGENDER`, `studentADDRESS`, `studentSTATE`, `studentPINCODE`, `studentSCHOOL`, `studentBOARD`, `studentCLASS`, `studentPASSWORD`, `studentCONCERN`, `studentPRIVACY`, `studentCreateTIME`, `studentCreateDATE`) VALUES
(1, 'MS00001', 'Soumalya', 'Mondal', 'asset/StudentProfilePicture/MS00001.png', 'iamsoumalya007@gmail.com', '9433331025', '8961805558', '19-01-1996', 'Male', '547/2 Rabindranath Tagore Road, Kolkata', 'West Bengal', '700077', 'Narula Institute Of Technology', 'WEST BENGAL BOARD OF SECONDARY EDUCATION, WEST BENGAL', 'Engineering', '$2y$10$MJ.5K998PBXt2v/H1Tx0t.fhGTBBViSnE3V12yNg/PnOTAYJcH6e2', 'Agree', 'Public', '00:46:04', '28-06-2022'),
(2, 'MD00001', 'Debasis', 'Mandal', 'asset/StudentProfilePicture/MD00001.png', 'mdebasis47@gmail.com', '8961805558', '9433331025', '03-11-1995', 'Male', '24/12/2 Mondalpara Lane, Kolkata', 'West Bengal', '700050', 'Institute Of Engineering & Management', 'WEST BENGAL BOARD OF SECONDARY EDUCATION, WEST BENGAL', 'Engineering', '$2y$10$/DF6b5TRsaPCPyBUNQp9JeAmvn4gpWkBnu32DxYBVfHxw6e/QQnxe', 'Agree', 'Private', '00:47:21', '28-06-2022');

-- --------------------------------------------------------

--
-- Table structure for table `studentenroll`
--

CREATE TABLE `studentenroll` (
  `id` int(10) NOT NULL,
  `studentID` varchar(15) NOT NULL,
  `courseID` varchar(15) NOT NULL,
  `courseNAME` varchar(100) NOT NULL,
  `courseEnrollDATE` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentenroll`
--

INSERT INTO `studentenroll` (`id`, `studentID`, `courseID`, `courseNAME`, `courseEnrollDATE`) VALUES
(1, 'MS00001', 'PHP001', 'PHP Server Site Scripting Language', '01-07-2022'),
(2, 'MD00001', 'PYT001', 'Python Beginner Guide', '01-07-2022');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `adminEMAIL` (`adminEMAIL`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `courseID` (`courseID`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `moduleID` (`moduleID`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `studentEMAIL` (`studentEMAIL`),
  ADD UNIQUE KEY `studentID` (`studentID`);

--
-- Indexes for table `studentenroll`
--
ALTER TABLE `studentenroll`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `studentenroll`
--
ALTER TABLE `studentenroll`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
