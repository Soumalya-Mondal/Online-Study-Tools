<?php
    // Include Database for processing
    include "_dbconnect.php";

    // Checking if Request Method is POST
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $adminEmail= $_POST['aemail'];
        $adminPassword= $_POST['apassword'];

        $adminSearchSQL= "SELECT * FROM `admin` WHERE adminEMAIL= '$adminEmail'";
        $adminSearchRESULT= mysqli_query($conn, $adminSearchSQL);
        $adminSearchROWS= mysqli_num_rows($adminSearchRESULT);

        if($adminSearchROWS== 1){
            $adminSearchROW= mysqli_fetch_assoc($adminSearchRESULT);
            if(password_verify($adminPassword, $adminSearchROW['adminPASSWORD'])){
                session_start();
                $_SESSION['adminLogin']= true;
                $_SESSION['adminID']= $adminSearchROW['adminID'];
                $_SESSION['userType']= 'admin';
                $_SESSION['adminName']= $adminSearchROW['adminNAME'];
                header("Location: ../adminpanel.php?loginA=true");
            }   // Password check end
            else{
                header("Location: ../admin.php?&loginp=true");
            }
        }   // Email check end
        else{
            header("Location: ../admin.php?logine=true");
        }
    }
?>