<div class="container py-3 user-select-none">
    <h1 class="text-center">Please Sign Up Here.</h1>
    <h5 class="text-center text-danger">* Field Required To Be Fill</h5>
</div>
<div class="container py-3 user-select-none">
    <form class="row g-3" method="post" action="partials/_studentsignuphandel.php" autocomplete="off" enctype="multipart/form-data">
        <div class="col-md-6">
            <label for="studentFname" class="form-label">First Name<span class="text-danger">*</span></label>
            <?php
            if (isset($_GET['sfname'])) {
                echo '<input type="text" name="sfname" class="form-control" id="studentFname" value="' . urldecode($_GET['sfname']) . '" required>';
            } else {
                echo '<input type="text" name="sfname" class="form-control" id="studentFname" required>';
            }
            ?>
        </div>
        <div class="col-md-6">
            <label for="studentLname" class="form-label">Last Name<span class="text-danger">*</span></label>
            <?php
            if (isset($_GET['slname'])) {
                echo '<input type="text" name="slname" class="form-control" id="studentLname" value="' . urldecode($_GET['slname']) . '" required>';
            } else {
                echo '<input type="text" name="slname" class="form-control" id="studentLname" required>';
            }
            ?>
        </div>
        <div class="col-md-4">
            <label for="studentPicture" class="form-label">Profile Pic.<span class="text-danger">* (&#x003C;2MB & .jpg .jpeg .png)</span></label>
            <input type="file" name="spicture" class="form-control" id="studentPicture" required>
        </div>
        <div class="col-md-3">
            <label for="studentPrivacy" class="form-label">Account Privacy<span class="text-danger">*</span></label>
            <select id="studentPrivacy" name="sprivacy" class="form-select" required>
                <option value="" selected></option>
                <option value="Public">Public (You're Picture Will Shown In Forum)</option>
                <option value="Private">Private (You're Picture Will'nt Shown In Forum)</option>
            </select>
        </div>
        <div class="col-md-5">
            <label for="studentGuardianNumber" class="form-label">Guardian Contact Num.<span class="text-danger">*</span></label>
            <input type="number" name="sgnumber" class="form-control" id="studentGuardianNumber" required>
        </div>
        <div class="col-md-4">
            <label for="studentEmail" class="form-label">Email Id.<span class="text-danger">*</span></label>
            <input type="email" name="semail" class="form-control" id="studentEmail" required>
        </div>
        <div class="col-md-4">
            <label for="studentPhone" class="form-label">Contact Num. (Without +91)<span class="text-danger">*</span></label>
            <input type="number" name="sphone" class="form-control" id="studentPhone" required>
        </div>
        <div class="col-md-2">
            <label for="studentDob" class="form-label">Date Of Birth<span class="text-danger">*</span></label>
            <input type="date" name="sdob" class="form-control" id="studentDob" required>
        </div>
        <div class="col-md-2">
            <label for="studentGender" class="form-label">Gender<span class="text-danger">*</span></label>
            <select id="studentGender" name="sgender" class="form-select" required>
                <option value="" selected></option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select>
        </div>
        <div class="col-md-6">
            <label for="studentAddress" class="form-label">Address (Without Pincode)<span class="text-danger">*</span></label>
            <?php
            if (isset($_GET['saddress'])) {
                echo '<input type="text" name="saddress" class="form-control" id="studentAddress" value="' . urldecode($_GET['saddress']) . '" required>';
            } else {
                echo '<input type="text" name="saddress" class="form-control" id="studentAddress" required>';
            }
            ?>
        </div>
        <div class="col-md-3">
            <label for="studentState" class="form-label">State<span class="text-danger">*</span></label>
            <select id="studentState" name="sstate" class="form-select" required>
                <option value="" selected></option>
                <option value="Andaman and Nicobar">Andaman and Nicobar</option>
                <option value="Andhra Pradesh">Andhra Pradesh</option>
                <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                <option value="Assam">Assam</option>
                <option value="Bihar">Bihar</option>
                <option value="Chandigarh">Chandigarh</option>
                <option value="Chhattisgarh">Chhattisgarh</option>
                <option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
                <option value="Daman and Diu">Daman and Diu</option>
                <option value="Delhi">Delhi</option>
                <option value="Goa">Goa</option>
                <option value="Gujarat">Gujarat</option>
                <option value="Haryana">Haryana</option>
                <option value="Himachal Pradesh">Himachal Pradesh</option>
                <option value="Jammu & Kashmir">Jammu & Kashmir</option>
                <option value="Jharkhand">Jharkhand</option>
                <option value="Karnataka">Karnataka</option>
                <option value="Kerala">Kerala</option>
                <option value="Lakshadweep">Lakshadweep</option>
                <option value="Madhya Pradesh">Madhya Pradesh</option>
                <option value="Maharashtra">Maharashtra</option>
                <option value="Manipur">Manipur</option>
                <option value="Meghalaya">Meghalaya</option>
                <option value="Mizoram">Mizoram</option>
                <option value="Nagaland">Nagaland</option>
                <option value="Orissa">Orissa</option>
                <option value="Puducherry">Puducherry</option>
                <option value="Punjab">Punjab</option>
                <option value="Rajasthan">Rajasthan</option>
                <option value="Sikkim">Sikkim</option>
                <option value="Tamil Nadu">Tamil Nadu</option>
                <option value="Telangana">Telangana</option>
                <option value="Tripura">Tripura</option>
                <option value="Uttar Pradesh">Uttar Pradesh</option>
                <option value="Uttarakhand">Uttarakhand</option>
                <option value="West Bengal">West Bengal</option>
            </select>
        </div>
        <div class="col-md-3">
            <label for="studentPincode" class="form-label">Pincode<span class="text-danger">*</span></label>
            <input type="number" name="spincode" class="form-control" id="studentPincode" required>
        </div>
        <div class="col-md-6">
            <label for="studentSchool" class="form-label">School<span class="text-danger">*</span></label>
            <?php
            if (isset($_GET['sschool'])) {
                echo '<input type="text" name="sschool" class="form-control" id="studentSchool" value="' . urldecode($_GET['sschool']) . '" required>';
            } else {
                echo '<input type="text" name="sschool" class="form-control" id="studentSchool" required>';
            }
            ?>
        </div>
        <div class="col-md-3">
            <label for="studentBoard" class="form-label">Board<span class="text-danger">*</span></label>
            <select id="studentBoard" name="sboard" class="form-select" required>
                <option value="" selected></option>
                <option value="CENTRAL BOARD OF SECONDARY EDUCATION, NEW DELHI">CENTRAL BOARD OF SECONDARY EDUCATION, NEW DELHI</option>
                <option value="NATIONAL INSTITUTE OF OPEN SCHOOLING, NEW DELHI">NATIONAL INSTITUTE OF OPEN SCHOOLING, NEW DELHI</option>
                <option value="COUNCIL FOR THE INDIAN SCHOOL CERTIFICATE EXAMINATIONS, NEW DELHI">COUNCIL FOR THE INDIAN SCHOOL CERTIFICATE EXAMINATIONS, NEW DELHI</option>
                <option value="BOARD OF INTERMEDIATE EDUCATION, ANDHRA PRADESH">BOARD OF INTERMEDIATE EDUCATION, ANDHRA PRADESH</option>
                <option value="BOARD OF SECONDARY EDUCATION, ANDHRA PRADESH">BOARD OF SECONDARY EDUCATION, ANDHRA PRADESH</option>
                <option value="A.P. OPEN SCHOOL SOCIETY, ANDHRA PRADESH">A.P. OPEN SCHOOL SOCIETY, ANDHRA PRADESH</option>
                <option value="ASSAM HIGHER SECONDARY EDUCATION COUNCIL, ASSAM">ASSAM HIGHER SECONDARY EDUCATION COUNCIL, ASSAM</option>
                <option value="BOARD OF SECONDARY EDUCATION, ASSAM">BOARD OF SECONDARY EDUCATION, ASSAM</option>
                <option value="BIHAR SCHOOL EXAMINATION BOARD, BIHAR">BIHAR SCHOOL EXAMINATION BOARD, BIHAR</option>
                <option value="BIHAR BOARD OF OPEN SCHOOLING AND EXAMINATION (BBOSE), BIHAR">BIHAR BOARD OF OPEN SCHOOLING AND EXAMINATION (BBOSE), BIHAR</option>
                <option value="CHHATISGARH BOARD OF SECONDARY EDUCATION, CHHATISGARH">CHHATISGARH BOARD OF SECONDARY EDUCATION, CHHATISGARH</option>
                <option value="CHHATISGARH STATE OPEN SCHOOL, CHHATISGARH">CHHATISGARH STATE OPEN SCHOOL, CHHATISGARH</option>
                <option value="GOA BOARD OF SECONDARY AND HIGHER SECONDARY EDUCATION, GOA">GOA BOARD OF SECONDARY AND HIGHER SECONDARY EDUCATION, GOA</option>
                <option value="GUJARAT SECONDARY AND HIGHER SECONDARY EDUCATION BOARD, GUJARAT">GUJARAT SECONDARY AND HIGHER SECONDARY EDUCATION BOARD, GUJARAT</option>
                <option value="BOARD OF SCHOOL EDUCATION, HARYANA">BOARD OF SCHOOL EDUCATION, HARYANA</option>
                <option value="H. P. BOARD OF SCHOOL EDUCATION, HIMACHAL PRADESH">H. P. BOARD OF SCHOOL EDUCATION, HIMACHAL PRADESH</option>
                <option value="THE J & K STATE BOARD OF SCHOOL EDUCATION, JAMMU">THE J & K STATE BOARD OF SCHOOL EDUCATION, JAMMU</option>
                <option value="JHARKHAND ACADEMIC COUNCIL,RANCHI">JHARKHAND ACADEMIC COUNCIL,RANCHI</option>
                <option value="GOVT. OF KARNATAKA DEPT. OF PRE-UNIVERSITY EDUCATION, KARNATAKA">GOVT. OF KARNATAKA DEPT. OF PRE-UNIVERSITY EDUCATION, KARNATAKA</option>
                <option value="KARNATAKA SECONDARY EDUCATION, EXAMINATION BOARD, KARNATAKA">KARNATAKA SECONDARY EDUCATION, EXAMINATION BOARD, KARNATAKA</option>
                <option value="KERALA BOARD OF PUBLIC EXAMINATION, KERALA">KERALA BOARD OF PUBLIC EXAMINATION, KERALA</option>
                <option value="KERALA BOARD OF HIGHER SECONDARY EDUCATION, KERALA">KERALA BOARD OF HIGHER SECONDARY EDUCATION, KERALA</option>
                <option value="BOARD OF VOCATIONAL HIGHER SECONDARY EDUCATION, KERALA">BOARD OF VOCATIONAL HIGHER SECONDARY EDUCATION, KERALA</option>
                <option value="MAHARASHTRA STATE BOARD OF SECONDARY AND HIGHER SECONDARY EDUCATION, MAHARASHTRA">MAHARASHTRA STATE BOARD OF SECONDARY AND HIGHER SECONDARY EDUCATION, MAHARASHTRA</option>
                <option value="BOARD OF SECONDARY EDUCATION, MADHYA PRADESH">BOARD OF SECONDARY EDUCATION, MADHYA PRADESH</option>
                <option value="M. P. STATE OPEN SCHOOL EDUCATION BOARD, MADHYA PRADESH">M. P. STATE OPEN SCHOOL EDUCATION BOARD, MADHYA PRADESH</option>
                <option value="BOARD OF SECONDARY EDUCATION, MANIPUR">BOARD OF SECONDARY EDUCATION, MANIPUR</option>
                <option value="COUNCIL OF HIGHER SECONDARY EDUCATION, MANIPUR">COUNCIL OF HIGHER SECONDARY EDUCATION, MANIPUR</option>
                <option value="MEGHALAYA BOARD OF SCHOOL EDUCATION, MEGHALAYA">MEGHALAYA BOARD OF SCHOOL EDUCATION, MEGHALAYA</option>
                <option value="MIZORAM BOARD OF SCHOOL EDUCATION, MIZORAM">MIZORAM BOARD OF SCHOOL EDUCATION, MIZORAM</option>
                <option value="NAGALAND BOARD OF SCHOOL EDUCATION, NAGALAND">NAGALAND BOARD OF SCHOOL EDUCATION, NAGALAND</option>
                <option value="BOARD OF SECONDARY EDUCATION, ODISHA">BOARD OF SECONDARY EDUCATION, ODISHA</option>
                <option value="COUNCIL OF HIGHER SECONDARY EDUCATION, ODISHA">COUNCIL OF HIGHER SECONDARY EDUCATION, ODISHA</option>
                <option value="PUNJAB SCHOOL EDUCATION BOARD, PUNJAB">PUNJAB SCHOOL EDUCATION BOARD, PUNJAB</option>
                <option value="BOARD OF SECONDARY EDUCATION, RAJASTHAN">BOARD OF SECONDARY EDUCATION, RAJASTHAN</option>
                <option value="RAJASTHAN STATE OPEN SCHOOL, RAJASTHAN">RAJASTHAN STATE OPEN SCHOOL, RAJASTHAN</option>
                <option value="STATE BOARD OF SCHOOL EXAMINATIONS (SEC.) & BOARD OF HIGHER SECONDARY, TAMIL NADU">STATE BOARD OF SCHOOL EXAMINATIONS (SEC.) & BOARD OF HIGHER SECONDARY, TAMIL NADU</option>
                <option value="BOARD OF SECONDARY EDUCATION, TELANGANA STATE">BOARD OF SECONDARY EDUCATION, TELANGANA STATE</option>
                <option value="TELANGANA STATE BOARD OF INTERMEDIATE EDUCATION, TELANGANA">TELANGANA STATE BOARD OF INTERMEDIATE EDUCATION, TELANGANA</option>
                <option value="TELANGANA OPEN SCHOOL SOCIETY, TELANGANA">TELANGANA OPEN SCHOOL SOCIETY, TELANGANA</option>
                <option value="TRIPURA BOARD OF SECONDARY EDUCATION, TRIPURA">TRIPURA BOARD OF SECONDARY EDUCATION, TRIPURA</option>
                <option value="U.P. BOARD OF HIGH SCHOOL & INTERMEDIATE EDUCATION, UTTAR PRADESH">U.P. BOARD OF HIGH SCHOOL & INTERMEDIATE EDUCATION, UTTAR PRADESH</option>
                <option value="BOARD OF SCHOOL EDUCATION, UTTARAKHAND">BOARD OF SCHOOL EDUCATION, UTTARAKHAND</option>
                <option value="WEST BENGAL BOARD OF SECONDARY EDUCATION, WEST BENGAL">WEST BENGAL BOARD OF SECONDARY EDUCATION, WEST BENGAL</option>
                <option value="WEST BENGAL COUNCIL OF HIGHER SECONDARY EDUCATION, WEST BENGAL">WEST BENGAL COUNCIL OF HIGHER SECONDARY EDUCATION, WEST BENGAL</option>
                <option value="THE WEST BENGAL COUNCIL OF RABINDRA OPEN SCHOOLING, WEST BENGAL">THE WEST BENGAL COUNCIL OF RABINDRA OPEN SCHOOLING, WEST BENGAL</option>
                <option value="WEST BENGAL STATE COUNCIL OF TECHNICAL & VOCATIONAL EDUCATION & SKILL DEVELOPMENT, WEST BENGAL">WEST BENGAL STATE COUNCIL OF TECHNICAL & VOCATIONAL EDUCATION & SKILL DEVELOPMENT, WEST BENGAL</option>
                <option value="MAHARISHI PATANJALI SANSKRIT SANSTHAN, NEW DELHI">MAHARISHI PATANJALI SANSKRIT SANSTHAN, NEW DELHI</option>
                <option value="URDU EDUCATION BOARD, NEW DELHI">URDU EDUCATION BOARD, NEW DELHI</option>
                <option value="BIHAR SANSKRIT SHIKSHA BOARD, BIHAR">BIHAR SANSKRIT SHIKSHA BOARD, BIHAR</option>
                <option value="U.P. BOARD OF SEC. SANSKRIT EDUCATION SANSKRIT BHAWAN, UTTAR PRADESH">U.P. BOARD OF SEC. SANSKRIT EDUCATION SANSKRIT BHAWAN, UTTAR PRADESH</option>
                <option value="ASSAM SANSKRIT BOARD, ASSAM">ASSAM SANSKRIT BOARD, ASSAM</option>
                <option value="JAMIA MILIA ISLAMIA, NEW DELHI">JAMIA MILIA ISLAMIA, NEW DELHI</option>
                <option value="UTTRAKHAND SANSKRIT SHIKSHA PARISHAD, UTTRAKHAND">UTTRAKHAND SANSKRIT SHIKSHA PARISHAD, UTTRAKHAND</option>
                <option value="STATE MADRASSA EDUCATION BOARD, ASSAM">STATE MADRASSA EDUCATION BOARD, ASSAM</option>
                <option value="BIHAR STATE MADRASA EDUCATION BOARD, BIHAR">BIHAR STATE MADRASA EDUCATION BOARD, BIHAR</option>
                <option value="WEST BENGAL BOARD OF MADRASAH EDUCATION, WEST BENGAL">WEST BENGAL BOARD OF MADRASAH EDUCATION, WEST BENGAL</option>
                <option value="CHHATTISGARH MADRASA BOARD, CHHATTISGARH">CHHATTISGARH MADRASA BOARD, CHHATTISGARH</option>
                <option value="UTTARAKHAND MADRASA EDUCATION BOARD, UTTARAKHAND">UTTARAKHAND MADRASA EDUCATION BOARD, UTTARAKHAND</option>
                <option value="ALIGARH MUSLIM UNIVERSITY BOARD OF SECONDARY & SR. SECONDARY EDUCATION, UTTAR PARDESH">ALIGARH MUSLIM UNIVERSITY BOARD OF SECONDARY & SR. SECONDARY EDUCATION, UTTAR PARDESH</option>
                <option value="INDIAN COUNCIL FOR HINDI & SANSKRIT EDUCATION, NEW DELHI">INDIAN COUNCIL FOR HINDI & SANSKRIT EDUCATION, NEW DELHI</option>
                <option value="DAYALBAGH EDUCATIONAL INSTITUTE, AGRA">DAYALBAGH EDUCATIONAL INSTITUTE, AGRA</option>
                <option value="BANASTHALI VIDYAPITH P.O., RAJASTHAN">BANASTHALI VIDYAPITH P.O., RAJASTHAN</option>
                <option value="BHUTAN COUNCIL FOR SCHOOL EXAMINATIONS & ASSESSMENT, BHUTAN">BHUTAN COUNCIL FOR SCHOOL EXAMINATIONS & ASSESSMENT, BHUTAN</option>
                <option value="CAMBRIDGE ASSESSMENT INTERNATIONAL EXAMINATIONS, UK">CAMBRIDGE ASSESSMENT INTERNATIONAL EXAMINATIONS, UK</option>
                <option value="CHHATTISGARH SANSKRIT BOARD, RAIPUR">CHHATTISGARH SANSKRIT BOARD, RAIPUR</option>
                <option value="MAURITIUS EXAMINATION SYNDICATE, MAURITIUS">MAURITIUS EXAMINATION SYNDICATE, MAURITIUS</option>
                <option value="NATIONAL EXAMINATIONS BOARD, NEPAL">NATIONAL EXAMINATIONS BOARD, NEPAL</option>
                <option value="PEARSON EDEXCEL LTD., UK">PEARSON EDEXCEL LTD., UK</option>
                <option value="INTERNATIONAL BACCALAUREATE, GENEVA">INTERNATIONAL BACCALAUREATE, GENEVA</option>
                <option value="NORTHWEST ACCREDITATION COMMISSION (NWAC), USA">NORTHWEST ACCREDITATION COMMISSION (NWAC), USA</option>
                <option value="CHHATTISGARH SANSKRIT BOARD, RAIPUR">CHHATTISGARH SANSKRIT BOARD, RAIPUR</option>
                <option value="SINGHANIA UNIVERSITY BOARD OF SECONDARY & SENIOR SECONDARY EDUCATION, RAJASTHAN">SINGHANIA UNIVERSITY BOARD OF SECONDARY & SENIOR SECONDARY EDUCATION, RAJASTHAN</option>
            </select>
        </div>
        <div class="col-md-3">
            <label for="studentClass" class="form-label">Class<span class="text-danger">*</span></label>
            <select id="studentClass" name="sclass" class="form-select" required>
                <option value="" selected></option>
                <option value="5">Class 5</option>
                <option value="6">Class 6</option>
                <option value="7">Class 7</option>
                <option value="8">Class 8</option>
                <option value="9">Class 9</option>
                <option value="10">Class 10</option>
                <option value="11">Class 11</option>
                <option value="12">Class 12</option>
                <option value="Engineering">Engineering</option>
                <option value="Medical">Medical</option>
            </select>
        </div>
        <div class="col-md-6">
            <label for="studentPassword" class="form-label">Password<span class="text-danger">*</span></label>
            <input type="password" name="spassword" class="form-control" id="studentPassword" required>
        </div>
        <div class="col-md-6">
            <label for="studentCPassword" class="form-label">Confirm Password<span class="text-danger">* (Same As Password)</span></label>
            <input type="password" name="scpassword" class="form-control" id="studentCPassword" required>
        </div>
        <div class="col-12 bg-light">
            <div class="form-check">
                <input class="form-check-input" name="sconcern" type="checkbox" id="agreeCheck" value="Agree" required>
                <label class="form-check-label" for="agreeCheck">
                    <span class="text-danger" style="font-weight: bold; font-size: 18px">* I hereby certify that the information provided above is true and correct.</span>
                </label>
            </div>
        </div>
        <div class="col-12 pt-3 text-center">
            <button type="submit" class="btn btn-success mx-3 my-2" style="width: 250px;">Register</button>
    </form>
    <!-- Signup Form End -->
    <button onclick="homePage()" class="btn btn-warning mx-3 my-2" style="width: 250px;">Home</button>
</div>
</div>