<?php
    include 'partials/_dbconnect.php';
?>
<div class="container marketing text-center user-select-none">
    <div class="row">
        <div class="col-lg-12">
    <?php
        $studentShowSQL = "SELECT * FROM `student` WHERE studentID= '".$_SESSION['studentID']."'";
        $studentShowRESULT = mysqli_query($conn, $studentShowSQL);
        $studentShowROWS = mysqli_num_rows($studentShowRESULT);
        if ($studentShowROWS == 1) {
            $studentShowROW = mysqli_fetch_assoc($studentShowRESULT);
            echo '<img class="rounded" src="' . $studentShowROW['studentPICTURE'] . '" alt="' . $_SESSION['studentName'] . '" width="25%">
                <h1 class="fw-normal my-3">Hello, ' . $_SESSION['studentName'] . '</h1>';
        }
    ?>
    <p>I hope you're doing good, and all you're family memeber are safe. So, this you're <button onclick="studentPanelPage()" class= "btn btn-warning" style="font-weight: bold">PANEL</button> you can control everything from here.</p>
        </div>
    </div>
</div>

<div class="container text-center user-select-none mt-3">
    <h2 class="my-3">Course List</h2>
    <table class="table table-hover table-bordered bg-light border">
        <thead>
            <tr>
                <th scope="col">Course Name</th>
                <th scope="col">Enroll Date</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $studentID= $_SESSION['studentID'];
                $courseShowSQL= "SELECT * FROM `studentenroll` WHERE studentID= '".$_SESSION['studentID']."'";
                $courseShowRESULT= mysqli_query($conn, $courseShowSQL);
                while($courseShowROW= mysqli_fetch_assoc($courseShowRESULT)){
                    echo '<tr>
                        <td>'.$courseShowROW['courseNAME'].'</td>
                        <td>'.$courseShowROW['courseEnrollDATE'].'</td>
                        <td class= "d-flex justify-content-center">
                            <form class="mx-2" method="post" action="coursemoduledetails.php">
                                <input type="hidden" name="courseid" value="'.$courseShowROW['courseID'].'">
                                <button type="submit" class="btn btn-success">Watch</button>
                            </form>
                            <form class="mx-2" method="post" action="">
                                <input type="hidden" name="studentId" value="">
                                <input type="hidden" name="courseId" value="">
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>';
                }
            ?>
        </tbody>
    </table>
</div>