<?php
    // Include database file to project
    include '_dbconnect.php';

    // Function for studentid create
    function studentID($conn ,$studentFName, $studentLName){
        // Cheking last id insert into database
        $studentIdSeacrSQL= "SELECT * FROM `student` WHERE studentID LIKE '".substr(strtoupper($studentFName), 0, 1).substr(strtoupper($studentLName), 0, 1)."%' ORDER BY studentID DESC LIMIT 1";
        $studentIdSearchRESULT= mysqli_query($conn,$studentIdSeacrSQL);
        $studentIdSearchROWS= mysqli_num_rows($studentIdSearchRESULT);

        if($studentIdSearchROWS> 0){
            $studentIdSeacrROW= mysqli_fetch_assoc($studentIdSearchRESULT);
            $studentOldID= $studentIdSeacrROW['studentID'];
            // add one to last id and return to main function
            return substr(strtoupper($studentLName), 0, 1).substr(strtoupper($studentFName), 0, 1).sprintf('%05s', substr(substr($studentOldID, 2)+1, -5));
        }
        else{
            // make start id and return to main function
            return substr(strtoupper($studentLName), 0, 1).substr(strtoupper($studentFName), 0, 1).'00001';
        }
    }

    function studentPicDIR($studentPicture, $studentID){
        $uploadDirectory= '../asset/StudentProfilePicture/';
        $uploadFile= $uploadDirectory.$studentID.'.'.basename($studentPicture['type']);
        $uploadFileType= strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));

        if($studentPicture['size']< 2097152 && ($uploadFileType== 'jpg' || $uploadFileType== 'jpeg' || $uploadFileType== 'png')){
            move_uploaded_file($studentPicture['tmp_name'], $uploadFile);
            if($uploadFileType== 'jpg' || $uploadFileType== 'jpeg'){
                $imageGD= imagecreatefromjpeg($uploadFile);
                $imageResized= imagescale($imageGD, 1000, 1000);
                imagepng($imageResized, $uploadDirectory.$studentID.'.png');
                unlink($uploadDirectory.$studentID.'.'.basename($studentPicture['type']));
            }
            if($uploadFileType== 'png'){
                $imageGD= imagecreatefrompng($uploadFile);
                $imageResized= imagescale($imageGD, 1000, 1000);
                imagepng($imageResized, $uploadDirectory.$studentID.'.png');
            }
            return 'asset/StudentProfilePicture/'.$studentID.'.png';
        }
        else{
            return false;
        }
    }

    // Check if request method is POST
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

        // Declare variable for storing POST Request Variable
        $studentFName= $_POST['sfname'];
        $studentLName= $_POST['slname'];
        $studentPicture= $_FILES['spicture'];
        $studentEmail= $_POST['semail'];
        $studentGuardianPhone= $_POST['sgnumber'];
        $studentPhone= $_POST['sphone'];
        $studentDob= $_POST['sdob'];
        $studentGender= $_POST['sgender'];
        $studentAddress= $_POST['saddress'];
        $studentState= $_POST['sstate'];
        $studentPincode= $_POST['spincode'];
        $studentSchool= $_POST['sschool'];
        $studentBoard= $_POST['sboard'];
        $studentClass= $_POST['sclass'];
        $studentPassword= $_POST['spassword'];
        $studentCPassword= $_POST['scpassword'];
        $studentConcern= $_POST['sconcern'];
        $studentPrivacy= $_POST['sprivacy'];

        // Existing Email Check
        $studentSearchEmailSQL= "SELECT * FROM `student` WHERE studentEMAIL= '$studentEmail'";
        $studentSearchEmailRESULT= mysqli_query($conn, $studentSearchEmailSQL);
        $studentSearchEmailROWS= mysqli_num_rows($studentSearchEmailRESULT);

        // Check email
        if($studentSearchEmailROWS== 0){
            // Cheking the phone number is correct or not
            if(strlen($studentPhone)== 10){
                // Cheking Password and Confirm Password are same or not
                if($studentPassword== $studentCPassword){
                    // Set default timezone
                    date_default_timezone_set('Asia/Kolkata');
                    // Set the function create student in
                    $studentID= studentID($conn, $studentFName, $studentLName);
                    // Set the function for uploading the picture
                    $studentPictureDIR= studentPicDIR($studentPicture, $studentID);
                    if($studentPictureDIR!= false){
                        // Insert student data into database
                        $studentInsertSQL= "INSERT INTO `student` (`studentID`, `studentFirstNAME`, `studentLastNAME`, `studentPICTURE`, `studentEMAIL`, `studentGuardianPHONE`, `studentPHONE`, `studentDOB`, `studentGENDER`, `studentADDRESS`, `studentSTATE`, `studentPINCODE`, `studentSCHOOL`, `studentBOARD`, `studentCLASS`, `studentPASSWORD`, `studentCONCERN`, `studentPRIVACY`, `studentCreateTIME`, `studentCreateDATE`) VALUES ('$studentID', '".ucfirst($studentFName)."', '".ucfirst($studentLName)."', '$studentPictureDIR', '$studentEmail', '$studentGuardianPhone', '$studentPhone', '".date('d-m-Y', strtotime($studentDob))."', '$studentGender', '$studentAddress', '$studentState', '$studentPincode', '$studentSchool', '$studentBoard', '$studentClass', '".password_hash($studentPassword, PASSWORD_DEFAULT)."', '$studentConcern', '$studentPrivacy', '".date('H:i:s')."', '".date('d-m-Y')."')";
                        $studentInserRESULT= mysqli_query($conn, $studentInsertSQL);
                        // If query is true
                        if($studentInserRESULT){
                            header('Location: ../index.php?signupS=true');
                        }
                    }   // Student picture check end
                    else{
                        header('Location: ../signup.php?signupPIC=true&sfname='.urlencode($studentFName).'&slname='.urlencode($studentLName).'&saddress='.urlencode($studentAddress).'&sschool='.urlencode($studentSchool).'');
                    }
                }   // Password check end
                else{
                    header('Location: ../signup.php?signupPW=true&sfname='.urlencode($studentFName).'&slname='.urlencode($studentLName).'&saddress='.urlencode($studentAddress).'&sschool='.urlencode($studentSchool).'');
                }
            }   // Phone number check end
            else{
                header('Location: ../signup.php?signupP=true&sfname='.urlencode($studentFName).'&slname='.urlencode($studentLName).'&saddress='.urlencode($studentAddress).'&sschool='.urlencode($studentSchool).'');
            }
        }   // Email check end
        else{
            header('Location: ../signup.php?signupE=true&sfname='.urlencode($studentFName).'&slname='.urlencode($studentLName).'&saddress='.urlencode($studentAddress).'&sschool='.urlencode($studentSchool).'');
        }
    }
?>