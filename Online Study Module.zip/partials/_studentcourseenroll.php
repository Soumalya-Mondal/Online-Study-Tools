<?php
    session_start();
    include '_dbconnect.php';

    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['studentLogin']) && $_SESSION['studentLogin']== true){
        $courseId= $_POST['courseid'];
        $studentId= $_POST['studentid'];
        $courseName= $_POST['coursename'];
        date_default_timezone_set('Asia/Kolkata');
        $enrollInsertSQL= "INSERT INTO `studentenroll` (`studentID`, `courseID`, `courseNAME`, `courseEnrollDATE`) VALUES ('$studentId', '$courseId', '$courseName', '".date('d-m-Y')."')";
        $enrollInsertRESULT= mysqli_query($conn, $enrollInsertSQL);
        if($enrollInsertRESULT){
            header('Location: ../coursepage.php?enroll=true');
        }
    }
    else{
        header('Location: ../coursepage.php?loginE=true');
    }
?>