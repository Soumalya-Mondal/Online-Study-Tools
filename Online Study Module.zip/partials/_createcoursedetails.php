<?php
    include '_dbconnect.php';

    function courseId($conn, $courseName){
        $courseSearchSQL= "SELECT * FROM `course` WHERE courseID LIKE '".substr(strtoupper($courseName), 0, 3)."%' ORDER BY courseID DESC LIMIT 1";
        $courseSearchRESULT= mysqli_query($conn, $courseSearchSQL);
        $courseSearchROWS= mysqli_num_rows($courseSearchRESULT);
        if($courseSearchROWS> 0){
            $courseSearchROW= mysqli_fetch_assoc($courseSearchRESULT);
            $courseOldID= $courseSearchROW['courseID'];
            return substr(strtoupper($courseName), 0, 3).sprintf('%03s', substr(substr($courseOldID, 3)+1, -3));
        }
        else{
            return substr(strtoupper($courseName), 0, 3).'001';
        }
    }

    function courseThumbnilDir($courseID, $courseThumbnil){
        $uploadDirectory= '../asset/CourseThumbnilPicture/';
        $uploadFile= $uploadDirectory.$courseID.'.'.basename($courseThumbnil['type']);
        $uploadFileType= strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));

        if($courseThumbnil['size']< 2097152 && ($uploadFileType== 'jpg' || $uploadFileType== 'jpeg' || $uploadFileType== 'png')){
            move_uploaded_file($courseThumbnil['tmp_name'], $uploadFile);
            if($uploadFileType== 'jpg' || $uploadFileType== 'jpeg'){
                $imageGD= imagecreatefromjpeg($uploadFile);
                $imageResized= imagescale($imageGD, 960, 540);
                imagepng($imageResized, $uploadDirectory.$courseID.'.png');
                unlink($uploadDirectory.$courseID.'.'.basename($courseThumbnil['type']));
            }
            if($uploadFileType== 'png'){
                $imageGD= imagecreatefrompng($uploadFile);
                $imageResized= imagescale($imageGD, 960, 540);
                imagepng($imageResized, $uploadDirectory.$courseID.'.png');
            }
            return 'asset/CourseThumbnilPicture/'.$courseID.'.png';
        }
        else{
            return false;
        }
    }

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $adminId= $_POST['adminid'];
        $adminName= $_POST['adminname'];
        $courseName= $_POST['coursename'];
        $courseThumbnil= $_FILES['coursethumbnil'];
        $courseDescription= $_POST['coursedescription'];
        $adminPassword= $_POST['adminpassword'];
        $adminCPassword= $_POST['admincpassword'];

        if($adminPassword== $adminCPassword){
            $adminSearchSQL= "SELECT * FROM `admin` WHERE adminID= '$adminId'";
            $adminSearchRESULT= mysqli_query($conn, $adminSearchSQL);
            $adminSearchROWS= mysqli_num_rows($adminSearchRESULT);
            if($adminSearchROWS== 1){
                $adminSearchROW= mysqli_fetch_assoc($adminSearchRESULT);
                if(password_verify($adminPassword, $adminSearchROW['adminPASSWORD'])){
                    date_default_timezone_set('Asia/Kolkata');
                    $courseID= courseId($conn, $courseName);
                    $courseThubmnilDIR= courseThumbnilDir($courseID, $courseThumbnil);
                    if($courseThubmnilDIR!= false){
                        $coursecreateInsertSQL= "INSERT INTO `course` (`courseID`, `courseNAME`, `courseTHUMBNIL`, `courseDESCRIPTION`, `courseCreateDATE`, `courseCreateNAME`, `courseCreateID`) VALUES ('$courseID', '".ucfirst($courseName)."','$courseThubmnilDIR', '$courseDescription', '".date('d-m-Y')."', '$adminName', '$adminId')";
                        $coursecreateInserRESULT= mysqli_query($conn, $coursecreateInsertSQL);
                        if($coursecreateInserRESULT){
                            header('Location: ../admincreatecourse.php?courseADD=true');
                        }
                    }
                    else{
                        header('Location: ../admincreatecourse.php?coursePIC=true');
                    }
                }
                else{
                    header('Location: ../admincreatecourse.php?courseAPE=true');
                }
            }
            else{
                header('Location: ../admincreatecourse.php?courseAIE=true');
            }
        }
        else{
            header('Location: ../admincreatecourse.php?coursePWM=true');
        }
    }
?>
<div class="container text-center user-select-none">
    <h2>Create Course Below</h2>
</div>
<div class="container user-select-none">
    <form class="row g-3" method="post" action="partials/_createcoursedetails.php" autocomplete="off" enctype="multipart/form-data">
        <input type="hidden" name="adminid" value="<?php echo $_SESSION['adminID']; ?>">
        <input type="hidden" name="adminname" value="<?php echo $_SESSION['adminName']; ?>">
        <div class="col-md-6">
            <label for="courseName" class="form-label">Course Name<span class="text-danger">*</span></label>
            <input type="text" name="coursename" class="form-control" id="courseName" required>
        </div>
        <div class="col-md-6">
            <label for="courseThumbnil" class="form-label">Course Thumbnil<span class="text-danger">*</span></label>
            <input type="file" name="coursethumbnil" class="form-control" id="courseThumbnil" required>
        </div>
        <div class="col-md-12">
            <label for="courseDescription" class="form-label">Course Description<span class="text-danger">*</span></label>
            <textarea class="form-control" name="coursedescription" id="courseDescription" rows="3"></textarea>
        </div>
        <div class="col-md-6">
            <label for="adminPassword" class="form-label">Admin Password<span class="text-danger">*</span></label>
            <input type="password" name="adminpassword" class="form-control" id="adminPassword" required>
        </div>
        <div class="col-md-6">
            <label for="adminCPassword" class="form-label">Admin Confirm Password<span class="text-danger">*</span></label>
            <input type="password" name="admincpassword" class="form-control" id="adminCPassword" required>
        </div>
        <div class="col-12 pt-3 text-center">
            <button type="submit" class="btn btn-success mx-3 my-2" style="width: 250px;">Add Course</button>
        </div>
    </form>
</div>
<div class="container text-center user-select-none my-5">
    <h2 class="mb-3">All Listed Course</h2>
    <table class="table table-hover table-bordered bg-light border" id="studentDetails">
        <thead>
            <tr>
                <th scope="col">Thumbnil</th>
                <th scope="col">Course Name</th>
                <th scope="col">Total Module</th>
                <th scope="col">Total Duration(minutes)</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $courseShowSQL= "SELECT * FROM `course` WHERE courseCreateID= '".$_SESSION['adminID']."'";
                $courseShowRESULT= mysqli_query($conn, $courseShowSQL);
                while($courseShowROW= mysqli_fetch_assoc($courseShowRESULT)){
                    echo '<tr>
                            <td width="250px"><img src="'.$courseShowROW['courseTHUMBNIL'].'" width="50%"></td>
                            <th>'.$courseShowROW['courseNAME'].'</th>
                            <td>12</td>
                            <td>120</td>
                            <td>Edit,Delete</td>
                        </tr>';
                }
            ?>
        </tbody>
    </table>
</div>