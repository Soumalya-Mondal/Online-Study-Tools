<?php
    include '_dbconnect.php';

    function moduleId($conn, $courseID){
        $moduleSearchSQL= "SELECT * FROM `module` WHERE moduleID LIKE '".$courseID."%' ORDER BY moduleID DESC LIMIT 1";
        $moduleSearchRESULT= mysqli_query($conn, $moduleSearchSQL);
        $moduleSearchROWS= mysqli_num_rows($moduleSearchRESULT);
        if($moduleSearchROWS> 0){
            $moduleSearchROW= mysqli_fetch_assoc($moduleSearchRESULT);
            $moduleOldID= $moduleSearchROW['moduleID'];
            return $courseID.'-'.sprintf('%04s', substr((substr($moduleOldID, 7, 11)+ 1), -4));
        }
        else{
            return $courseID.'-0001';
        }
    }

    function videoId($moduleVideo){
        parse_str(parse_url($moduleVideo, PHP_URL_QUERY), $youtubeVidoeID);
        return $youtubeVidoeID['v'];
    }

    function moduleThumbnilDir($moduleID, $moduleThumbnil){
        $uploadDirectory= '../asset/ModuleThumbnilPicture/';
        $uploadFile= $uploadDirectory.$moduleID.'.'.basename($moduleThumbnil['type']);
        $uploadFileType= strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));

        if($moduleThumbnil['size']< 2097152 && ($uploadFileType== 'jpg' || $uploadFileType== 'jpeg' || $uploadFileType== 'png')){
            move_uploaded_file($moduleThumbnil['tmp_name'], $uploadFile);
            if($uploadFileType== 'jpg' || $uploadFileType== 'jpeg'){
                $imageGD= imagecreatefromjpeg($uploadFile);
                $imageResized= imagescale($imageGD, 960, 540);
                imagepng($imageResized, $uploadDirectory.$moduleID.'.png');
                unlink($uploadDirectory.$moduleID.'.'.basename($moduleThumbnil['type']));
            }
            if($uploadFileType== 'png'){
                $imageGD= imagecreatefrompng($uploadFile);
                $imageResized= imagescale($imageGD, 960, 540);
                imagepng($imageResized, $uploadDirectory.$moduleID.'.png');
            }
            return 'asset/ModuleThumbnilPicture/'.$moduleID.'.png';
        }
        else{
            return false;
        }
    }

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $adminId= $_POST['adminid'];
        $adminName= $_POST['adminname'];
        $courseId= $_POST['courseid'];
        $moduleName= $_POST['modulename'];
        $moduleThumbnil= $_FILES['modulethumbnil'];
        $moduleVideo= $_POST['modulevideo'];
        $moduleDescription= $_POST['moduledescription'];
        $adminPassword= $_POST['adminpassword'];
        $adminCPassword= $_POST['admincpassword'];

        if($adminPassword== $adminCPassword){
            $adminSearchSQL= "SELECT * FROM `admin` WHERE adminID= '$adminId'";
            $adminSearchRESULT= mysqli_query($conn, $adminSearchSQL);
            $adminSearchROWS= mysqli_num_rows($adminSearchRESULT);
            if($adminSearchROWS== 1){
                $adminSearchROW= mysqli_fetch_assoc($adminSearchRESULT);
                if(password_verify($adminPassword, $adminSearchROW['adminPASSWORD'])){
                    date_default_timezone_set('Asia/Kolkata');
                    $moduleID= moduleId($conn, $courseId);
                    $videoID= videoId($moduleVideo);
                    $moduleThumbnilDIR= moduleThumbnilDir($moduleID, $moduleThumbnil);
                    if($moduleThumbnilDIR!= false){
                        $modulecreateInsertSQL= "INSERT INTO `module` (`moduleID`, `courseID`, `moduleNAME`, `moduleTHUMBNIL`, `moduleVideoID`, `moduleDESCRIPTION`, `moduleCreateDATE`, `moduleCreateNAME`, `moduleCreateID`) VALUES ('$moduleID', '$courseId', '$moduleName', '$moduleThumbnilDIR', '$videoID', '$moduleDescription', '".date('d-m-Y')."', '$adminId', '$adminName')";
                        $modulecreateInsertRESULT= mysqli_query($conn, $modulecreateInsertSQL);
                        if($modulecreateInsertRESULT){
                            header('Location: ../admincreatemodule.php?moduleADD=true');
                        }
                    }
                    else{
                        header('Location: ../admincreatemodule.php?modulePIC=true');
                    }
                }
                else{
                    header('Location: ../admincreatemodule.php?moduleAPE=true');
                }
            }
            else{
                header('Location: ../admincreatemodule.php?moduleAIE=true');
            }
        }
        else{
            header('Location: ../admincreatemodule.php?modulePWM=true');
        }
    }
?>
<div class="container text-center user-select-none">
    <h2>Create Module Below</h2>
</div>
<div class="container user-select-none">
    <form class="row g-3" method="post" action="partials/_createmoduledetails.php" autocomplete="off" enctype="multipart/form-data">
        <input type="hidden" name="adminid" value="<?php echo $_SESSION['adminID']; ?>">
        <input type="hidden" name="adminname" value="<?php echo $_SESSION['adminName']; ?>">
        <div class="col-md-12">
            <label for="courseName" class="form-label">Course Name<span class="text-danger">*</span></label>
            <select id="courseName" name="courseid" class="form-select" required>
                <option value="" selected></option>
                <?php
                    $courseShowSQL= "SELECT * FROM `course` WHERE courseCreateID= '".$_SESSION['adminID']."'";
                    $courseShowRESULT= mysqli_query($conn, $courseShowSQL);
                    while($courseShowROW= mysqli_fetch_assoc($courseShowRESULT)){
                        echo '<option value="'.$courseShowROW['courseID'].'">'.$courseShowROW['courseNAME'].'</option>';
                    }
                ?>
            </select>
        </div>
        <div class="col-md-6">
            <label for="moduleName" class="form-label">Module Name<span class="text-danger">*</span></label>
            <input type="text" name="modulename" class="form-control" id="moduleName" required>
        </div>
        <div class="col-md-6">
            <label for="moduleThumbnil" class="form-label">Module Thumbnil<span class="text-danger">*</span></label>
            <input type="file" name="modulethumbnil" class="form-control" id="moduleThumbnil" required>
        </div>
        <div class="col-md-12">
            <label for="modulVideo" class="form-label">Module Video Link<span class="text-danger">*</span></label>
            <input type="text" name="modulevideo" class="form-control" id="modulVideo" required>
        </div>
        <div class="col-md-12">
            <label for="moduleDescription" class="form-label">Module Description<span class="text-danger">*</span></label>
            <textarea class="form-control" name="moduledescription" id="moduleDescription" rows="3"></textarea>
        </div>
        <div class="col-md-6">
            <label for="adminPassword" class="form-label">Admin Password<span class="text-danger">*</span></label>
            <input type="password" name="adminpassword" class="form-control" id="adminPassword" required>
        </div>
        <div class="col-md-6">
            <label for="adminCPassword" class="form-label">Admin Confirm Password<span class="text-danger">*</span></label>
            <input type="password" name="admincpassword" class="form-control" id="adminCPassword" required>
        </div>
        <div class="col-12 pt-3 text-center">
            <button type="submit" class="btn btn-success mx-3 my-2" style="width: 250px;">Add Module</button>
        </div>
    </form>
</div>