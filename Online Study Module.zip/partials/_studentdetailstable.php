<div class="container user-select-none">
    <table class="table table-hover table-bordered bg-light" id="studentDetails">
        <thead>
            <tr>
                <th scope="col">Picture</th>
                <th scope="col">Name</th>
                <th scope="col">Student Num.</th>
                <th scope="col">Guardian Num.</th>
                <th scope="col">School</th>
                <th scope="col">Class</th>
            </tr>
        </thead>
        <tbody>
            <?php
                include 'partials/_dbconnect.php';
                $studentDetailsSQL= "SELECT * FROM `student`";
                $studentDetailsRESULT= mysqli_query($conn, $studentDetailsSQL);
                while($studentDetailsROW= mysqli_fetch_assoc($studentDetailsRESULT)){
                    echo '<tr>
                            <td width="130px"><img class="rounded-circle" src="'.$studentDetailsROW['studentPICTURE'].'" width="100%"></td>
                            <th>'.$studentDetailsROW['studentFirstNAME'].' '.$studentDetailsROW['studentLastNAME'].'</th>
                            <td>'.$studentDetailsROW['studentPHONE'].'</td>
                            <td>'.$studentDetailsROW['studentGuardianPHONE'].'</td>
                            <td>'.$studentDetailsROW['studentSCHOOL'].'</td>
                            <td>'.$studentDetailsROW['studentCLASS'].'</td>
                        </tr>';
                }
            ?>
        </tbody>
    </table>
</div>