<?php
    $servername= 'localhost';
    $username= 'root';
    $password= '';
    $database= 'exam(eon)';

    $conn= mysqli_connect($servername, $username, $password, $database);

    if(!$conn){
        exit();
    }
?>