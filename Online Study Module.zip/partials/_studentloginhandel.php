<?php
    // Include database file to project
    include '_dbconnect.php';

    // Cheking if request method is POST
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $studentEmail= $_POST['semail'];
        $studentPassword= $_POST['spassword'];

        // Student search enquery
        $studentSearchSQL= "SELECT * FROM `student` WHERE studentEMAIL= '$studentEmail'";
        $studentSearchRESULT= mysqli_query($conn, $studentSearchSQL);
        $studentSearchROWS= mysqli_num_rows($studentSearchRESULT);

        // Check if there is any email id exits or not
        if($studentSearchROWS== 1){
            $studentSearchROW= mysqli_fetch_assoc($studentSearchRESULT);

            // Cheking password is correct or not
            if(password_verify($studentPassword, $studentSearchROW['studentPASSWORD'])){
                session_start();
                $_SESSION['studentLogin']= true;
                $_SESSION['userType']= 'student';
                $_SESSION['studentID']= $studentSearchROW['studentID'];
                $_SESSION['studentName']= $studentSearchROW['studentFirstNAME'].' '.$studentSearchROW['studentLastNAME'];

                // Redirect the student in main page
                header('Location: ../index.php?loginS=true');
            }   // Password check end
            else{
                header('Location: ../login.php?loginP=true');
            }
        }   // Email Id check end
        else{
            header('Location: ../login.php?loginE=true');
        }
    }
?>