<?php
    // Start Session
    session_start();

    // Declair some variable
    $loginA= false;

    // Took data from GET request
    if(isset($_GET['loginA']) && $_GET['loginA']== true){
        $loginA= true;
    }
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title Here -->
    <title>Exam(eON) | A Online Learning Platform</title>
    <!-- Tabicon Source -->
    <link rel="shortcut icon" href="resource/img/tabicon.png" type="image/x-icon">
    <!-- Bootstrap css -->
    <link href="resource/css/bootstrap.min.css" rel="stylesheet">
    <!-- Fontawesome js -->
    <script src="https://kit.fontawesome.com/be27dc6540.js" crossorigin="anonymous"></script>
</head>

<body style="background-color: #f6f0eb">
    <!-- Header Start -->
    <div class="sticky-top user-select-none bg-light bg-opacity-75">
        <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom border-dark">
            <a onclick="homePage()" class="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark mx-5">
                <img onMouseOver="this.style.cursor='pointer'" src="resource/img/navbaricon.png" style="width: 200px" alt="Navbar Icon">
            </a>
            <ul class="nav nav-pills col-12 col-md-auto mb-2 justify-content-center mb-md-0">
                <?php
                if ((isset($_SESSION['studentLogin']) && $_SESSION['studentLogin'] == true) || (isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true)) {
                    echo '<li><button onclick="homePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Home</button></li>
                        <li><button onclick="coursePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Course</button></li>
                        <li><a href="#" class="nav-link px-2 text-dark" style="font-weight: bold">About Us</a></li>';
                } else {
                    echo '<li><button onclick="homePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Home</button></li>
                        <li><button onclick="coursePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Course</button></li>
                        <li><a href="#" class="nav-link px-2 text-dark" style="font-weight: bold">About Us</a></li>
                        <li><button onclick="adminPage()" class="nav-link px-2 text-dark" style="font-weight: bold;">Admin</button></li>';
                }
                ?>
            </ul>
            <div class="col-md-3 text-end mx-5">
                <?php
                if ((isset($_SESSION['studentLogin']) && $_SESSION['studentLogin'] == true) || (isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true)) {
                    if ($_SESSION['userType'] == 'student') {
                        echo '<span style="font-weight: bold">Hello, ' . $_SESSION['studentName'] . '</span>
                            <button onclick="logoutPage()" class="btn btn-danger mx-2">Log Out</button>';
                    }
                    if ($_SESSION['userType'] == 'admin') {
                        echo '<span style="font-weight: bold">Hello, ' . $_SESSION['adminName'] . '</span>
                            <button onclick="logoutPage()" class="btn btn-danger mx-2">Log Out</button>';
                    }
                } else {
                    echo '<button onclick="loginPage()" class="btn btn-success mx-2">Log In</button>
                        <button onclick="signupPage()" class="btn btn-warning mx-2">Sign Up</button>';
                }
                ?>
            </div>
        </header>
    </div>
    <!-- Header End -->
    <!-- Alert section start here -->
    <?php
        if($loginA){
            echo '<div class="container user-select-none">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>SUCCESS&#x2705;</strong> Welcome Back, '.$_SESSION['adminName'].'
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>';
        }
    ?>
    <!-- Alert section end here -->
    <!-- Content Section Start Here -->
    <?php
        if(isset($_SESSION['adminLogin']) && $_SESSION['adminLogin']== true){
            echo '<div class="container marketing text-center user-select-none">
                <div class="row">
                    <!-- Student Details -->
                    <div class="col-lg-4 py-4">
                        <img src="resource/img/studentdetails.png" alt="Student Details">
                        <h2 class="fw-normal">Student Details</h2>
                        <p><button onclick="studentDetailsPage()" class="btn btn-dark">Details &#x27A1;</button></p>
                    </div>
                    <!-- Student Result Page -->
                    <div class="col-lg-4 py-4">
                        <img src="resource/img/studentresult.png" alt="Student Result">
                        <h2 class="fw-normal">Student Result</h2>
                        <p><button onclick="studentResultPage()" class="btn btn-dark">Result &#x27A1;</button></p>
                    </div>
                    <!-- Forum Comment -->
                    <div class="col-lg-4 py-4">
                        <img src="resource/img/forumcomment.png" alt="Forum Comment">
                        <h2 class="fw-normal">Forum Comment</h2>
                        <p><button onclick="forumCommentPage()" class="btn btn-dark">Forum &#x27A1;</button></p>
                    </div>
                    <!-- Course Create -->
                    <div class="col-lg-4 py-4">
                        <img src="resource/img/coursecreate.png" alt="Create Course">
                        <h2 class="fw-normal">Create Course</h2>
                        <p><button onclick="createCoursePage()" class="btn btn-dark">Course &#x27A1;</button></p>
                    </div>
                    <!-- Module Create -->
                    <div class="col-lg-4 py-4">
                        <img src="resource/img/modulecreate.png" alt="Create Module">
                        <h2 class="fw-normal">Create Module</h2>
                        <p><button onclick="createModulePage()" class="btn btn-dark">Module &#x27A1;</button></p>
                    </div>
                    <!-- Exam Create -->
                    <div class="col-lg-4 py-4">
                        <img src="resource/img/examcreate.png" alt="Create Exam">
                        <h2 class="fw-normal">Create Exam</h2>
                        <p><button onclick="createExamPage()" class="btn btn-dark">Exam &#x27A1;</button></p>
                    </div>
                </div>
            </div>';
        }
        if(isset($_SESSION['studentLogin']) && $_SESSION['studentLogin']){
            echo '<div class="container user-select-none">
                    <h2 class="text-center text-danger">'.$_SESSION['studentName'].' You\'re Not Allowed Here.</h2>
                </div>';
        }
        if(!isset($_SESSION['studentLogin']) && !isset($_SESSION['adminLogin'])){
            echo '<div class="container">
                    <img class="img-fluid" src="resource/img/noaccess.jpg" alt="No Access">
                </div>';
        }
    ?>
    <!-- Content Section End Here -->
    <!-- Footer Start -->
    <div class="user-select-none my-3">
        <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top bg-light">
            <div class="col-md-4 d-flex align-items-center">
                <a onclick="homePage()" class="mb-3 me-2 mb-md-0 text-muted lh-1 mx-5">
                    <img onMouseOver="this.style.cursor='pointer'" style="width: 130px" src="resource/img/navbaricon.png" alt="tabicon">
                </a>
                <span class="mb-3 mb-md-0 mx-4" style="font-weight: bold; font-size: 16px">©Exam(eON), By Soumalya&#127851;</span>
            </div>
        </footer>
    </div>
    <!-- Footer End -->
    <!-- Bootstrap js -->
    <script src="resource/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="resource/js/exameon.js"></script>
</body>

</html>