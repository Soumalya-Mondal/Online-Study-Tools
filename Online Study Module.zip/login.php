<?php
    // Start Session
    session_start();

    // Declare some error variable
    $loginP= false;
    $loginE= false;

    // Checking the error via GET method
    if(isset($_GET['loginP']) && $_GET['loginP']== true){
        $loginP= true;
    }
    if(isset($_GET['loginE']) && $_GET['loginE']== true){
        $loginE= true;
    }
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title Here -->
    <title>Exam(eON) | A Online Learning Platform</title>
    <!-- Tabicon Source -->
    <link rel="shortcut icon" href="resource/img/tabicon.png" type="image/x-icon">
    <!-- Bootstrap css -->
    <link href="resource/css/bootstrap.min.css" rel="stylesheet">
    <!-- Fontawesome js -->
    <script src="https://kit.fontawesome.com/be27dc6540.js" crossorigin="anonymous"></script>
</head>

<body style="background-color: #f6f0eb">
    <!-- Header Start -->
    <div class="sticky-top user-select-none bg-light bg-opacity-75">
        <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom border-dark">
            <a onclick="homePage()" class="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark mx-5">
                <img onMouseOver="this.style.cursor='pointer'" src="resource/img/navbaricon.png" style="width: 200px" alt="Navbar Icon">
            </a>
            <ul class="nav nav-pills col-12 col-md-auto mb-2 justify-content-center mb-md-0">
                <?php
                    if((isset($_SESSION['studentLogin']) && $_SESSION['studentLogin'] == true) || (isset($_SESSION['adminLogin']) && $_SESSION['adminLogin']== true)){
                        if($_SESSION['userType']== 'student'){
                            echo '<li><button onclick="homePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Home</button></li>
                                <li><button onclick="coursePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Course</button></li>
                                <li><a href="#" class="nav-link px-2 text-dark" style="font-weight: bold">About Us</a></li>
                                <li><button onclick="studentPanelPage()" class="nav-link px-2 text-dark" style="font-weight: bold;">Student Panel</button></li>';
                        }
                        if($_SESSION['userType']== 'admin'){
                            echo '<li><button onclick="homePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Home</button></li>
                                <li><button onclick="coursePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Course</button></li>
                                <li><a href="#" class="nav-link px-2 text-dark" style="font-weight: bold">About Us</a></li>
                                <li><button onclick="adminPanelPage()" class="nav-link px-2 text-dark" style="font-weight: bold;">Admin Panel</button></li>';
                        }
                    }
                    else{
                        echo '<li><button onclick="homePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Home</button></li>
                            <li><button onclick="coursePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Course</button></li>
                            <li><a href="#" class="nav-link px-2 text-dark" style="font-weight: bold">About Us</a></li>
                            <li><button onclick="adminPage()" class="nav-link px-2 text-dark" style="font-weight: bold;">Admin</button></li>';
                    }
                ?>
            </ul>
            <div class="col-md-3 text-end mx-5">
                <?php
                    if((isset($_SESSION['studentLogin']) && $_SESSION['studentLogin'] == true) || (isset($_SESSION['adminLogin']) && $_SESSION['adminLogin']== true)){
                        if($_SESSION['userType']== 'student'){
                            echo '<span style="font-weight: bold">Hello, '.$_SESSION['studentName'].'</span>
                                <button onclick="logoutPage()" class="btn btn-danger mx-2">Log Out</button>';
                        }
                        if($_SESSION['userType']== 'admin'){
                            echo '<span style="font-weight: bold">Hello, '.$_SESSION['adminName'].'</span>
                                <button onclick="logoutPage()" class="btn btn-danger mx-2">Log Out</button>';
                        }
                    }
                    else{
                        echo '<button onclick="signupPage()" class="btn btn-warning mx-2">Sign Up</button>';
                    }
                ?>
            </div>
        </header>
    </div>
    <!-- Header End -->
    <!-- Alert Section Start -->
    <?php
        if($loginP){
            echo '<div class="container">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>ERROR&#x1F534;</strong> You\'re Password is INCORRECT.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>';
        }
        if($loginE){
            echo '<div class="container">
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>ERROR&#x1F534;</strong> You\'re Email ID is INCORRECT.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>';
        }
    ?>
    <!-- Alert Section End -->
    <!-- Login Form Section Start -->
    <div class="container marketing user-select-none">
        <div class="row featurette align-items-center">
            <div class="col-md-7 py-3">
                <img src="resource/img/loginstudent.png" width="100%" alt="Login Main">
            </div>
            <div class="col-md-5 border border-dark py-3 bg-light">
                <?php
                    if((isset($_SESSION['studentLogin']) && $_SESSION['studentLogin'] == true) || (isset($_SESSION['adminLogin']) && $_SESSION['adminLogin']== true)){
                        if($_SESSION['userType']== 'student'){
                            echo '<div class="container user-select-none text-center">
                                    <h2 class="text-danger">You Already Logged In As</h2><br><span style="font-size: 24px; font-weight: bold;">'.$_SESSION['studentName'].' ('.ucfirst($_SESSION['userType']).')</span>
                                </div>';
                        }
                        if($_SESSION['userType']== 'admin'){
                            echo '<div class="container user-select-none text-center">
                                    <h2 class="text-danger">You Already Logged In As</h2><br><span style="font-size: 24px; font-weight: bold;">'.$_SESSION['adminName'].' ('.ucfirst($_SESSION['userType']).')</span>
                                </div>';
                        }
                    }
                    else{
                        echo '<h2 class="text-center">Log In</h2>
                            <form method="post" action="partials/_studentloginhandel.php" autocomplete="off">
                                <div class="mb-3">
                                    <label for="studentemail" class="form-label">Email Id.<span class="text-danger">*</span></label>
                                    <input type="email" name="semail" class="form-control" id="studentemail" required>
                                </div>
                                <div class="mb-3">
                                    <label for="studentpassword" class="form-label">Password<span class="text-danger">*</span></label>
                                        <input type="password" name="spassword" class="form-control" id="studentpassword" required>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success" style="width: 200px">Submit</button>
                                </div>
                            </form>';
                    }
                ?>
            </div>
        </div>
    </div>
    <!-- Login Form Section End -->
    <!-- Footer Start -->
    <div class="user-select-none my-3">
        <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top bg-light">
            <div class="col-md-4 d-flex align-items-center">
                <a onclick="homePage()" class="mb-3 me-2 mb-md-0 text-muted lh-1 mx-5">
                    <img onMouseOver="this.style.cursor='pointer'" style="width: 130px" src="resource/img/navbaricon.png" alt="tabicon">
                </a>
                <span class="mb-3 mb-md-0 mx-4" style="font-weight: bold; font-size: 16px">©Exam(eON), By Soumalya&#127851;</span>
            </div>
        </footer>
    </div>
    <!-- Footer End -->
    <!-- Bootstrap js -->
    <script src="resource/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="resource/js/exameon.js"></script>
</body>

</html>