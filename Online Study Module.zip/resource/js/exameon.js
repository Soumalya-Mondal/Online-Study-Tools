function homePage(){
    location.href= "index.php";
}

function loginPage(){
    location.href= "login.php";
}

function signupPage(){
    location.href= "signup.php";
}

function logoutPage(){
    location.href= "partials/_logout.php";
}

function coursePage(){
    location.href= "coursepage.php";
}

function adminPage(){
    location.href= "admin.php";
}

function adminPanelPage(){
    location.href= "adminpanel.php";
}

function studentPanelPage(){
    location.href= "studentpanel.php";
}

function studentDetailsPage(){
    location.href= "adminstudentdetails.php";
}

function studentResultPage(){
    location.href= "adminstudentresult.php";
}

function forumCommentPage(){
    location.href= "adminforumcomment.php";
}

function createCoursePage(){
    location.href= "admincreatecourse.php";
}

function createModulePage(){
    location.href= "admincreatemodule.php";
}

function createExamPage(){
    location.href= "admincreateexam.php";
}