<?php
    // Start Session
    session_start();

    $courseADD= false;
    $coursePIC= false;
    $courseAPE= false;
    $courseAIE= false;
    $coursePWM= false;

    if(isset($_GET['courseADD']) && $_GET['courseADD']== true){
        $courseADD= true;
    }
    if(isset($_GET['coursePIC']) && $_GET['coursePIC']== true){
        $coursePIC= true;
    }
    if(isset($_GET['courseAPE']) && $_GET['courseAPE']== true){
        $coursePWI= true;
    }
    if(isset($_GET['courseAIE']) && $_GET['courseAIE']== true){
        $courseAIE= true;
    }
    if(isset($_GET['coursePWM']) && $_GET['coursePWM']== true){
        $coursePWM= true;
    }
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title Here -->
    <title>Exam(eON) | A Online Learning Platform</title>
    <!-- Tabicon Source -->
    <link rel="shortcut icon" href="resource/img/tabicon.png" type="image/x-icon">
    <!-- Bootstrap css -->
    <link href="resource/css/bootstrap.min.css" rel="stylesheet">
    <!-- Fontawesome js -->
    <script src="https://kit.fontawesome.com/be27dc6540.js" crossorigin="anonymous"></script>
</head>

<body style="background-color: #f6f0eb">
    <!-- Header Start -->
    <div class="sticky-top user-select-none bg-light bg-opacity-75">
        <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom border-dark">
            <a onclick="homePage()" class="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark mx-5">
                <img onMouseOver="this.style.cursor='pointer'" src="resource/img/navbaricon.png" style="width: 200px" alt="Navbar Icon">
            </a>
            <ul class="nav nav-pills col-12 col-md-auto mb-2 justify-content-center mb-md-0">
                <?php
                    if((isset($_SESSION['studentLogin']) && $_SESSION['studentLogin'] == true) || (isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true)){
                        if($_SESSION['userType']== 'student'){
                            echo '<li><button onclick="homePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Home</button></li>
                                <li><button onclick="coursePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Course</button></li>
                                <li><a href="#" class="nav-link px-2 text-dark" style="font-weight: bold">About Us</a></li>
                                <li><button onclick="studentPanelPage()" class="nav-link px-2 text-dark" style="font-weight: bold;">Student Panel</button></li>';
                        }
                        if($_SESSION['userType']== 'admin'){
                            echo '<li><button onclick="homePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Home</button></li>
                                <li><button onclick="coursePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Course</button></li>
                                <li><a href="#" class="nav-link px-2 text-dark" style="font-weight: bold">About Us</a></li>
                                <li><button onclick="adminPanelPage()" class="nav-link px-2 text-dark" style="font-weight: bold;">Admin Panel</button></li>';
                        }                       
                    }
                    else {
                        echo '<li><button onclick="homePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Home</button></li>
                            <li><button onclick="coursePage()" class="nav-link px-2 text-dark" style="font-weight: bold">Course</button></li>
                            <li><a href="#" class="nav-link px-2 text-dark" style="font-weight: bold">About Us</a></li>
                            <li><button onclick="adminPage()" class="nav-link px-2 text-dark" style="font-weight: bold;">Admin</button></li>';
                    }
                ?>
            </ul>
            <div class="col-md-3 text-end mx-5">
                <?php
                    if((isset($_SESSION['studentLogin']) && $_SESSION['studentLogin'] == true) || (isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true)){
                        if($_SESSION['userType']== 'student'){
                            echo '<span style="font-weight: bold">Hello, ' . $_SESSION['studentName'] . '</span>
                                <button onclick="logoutPage()" class="btn btn-danger mx-2">Log Out</button>';
                        }
                        if($_SESSION['userType']== 'admin'){
                            echo '<span style="font-weight: bold">Hello, ' . $_SESSION['adminName'] . '</span>
                                <button onclick="logoutPage()" class="btn btn-danger mx-2">Log Out</button>';
                        }
                    }
                    else{
                        echo '<button onclick="loginPage()" class="btn btn-success mx-2">Log In</button>
                            <button onclick="signupPage()" class="btn btn-warning mx-2">Sign Up</button>';
                    }
                ?>
            </div>
        </header>
    </div>
    <!-- Header End -->
    <!-- Alert section start -->
    <?php
        if($courseADD){
            echo '<div class="container">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>SUCCESS&#x2705;</strong> Course Added Successfully.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>';
        }
        if($coursePIC){
            echo '<div class="container">
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>ERROR&#x1F534;</strong> Not Compatiable Thumbnil.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>';
        }
        if($courseAPE){
            echo '<div class="container">
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>ERROR&#x1F534;</strong> You Entered Wrong Password.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>';
        }
        if($courseAIE){
            echo '<div class="container">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>ERROR&#x1F534;</strong> You\'re Admin ID Is Incorrect.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>';
        }
        if($coursePWM){
            echo '<div class="container">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>ERROR&#x1F534;</strong> Password And Confirm Password Is Not Matched.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>';
        }
    ?>
    <!-- Alert section end -->
    <!-- Content Section Start Here -->
    <?php
        if(isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true){
            include 'partials/_createcoursedetails.php';
        }
        if(isset($_SESSION['studentLogin']) && $_SESSION['studentLogin']){
            echo '<div class="container">
                    <h2 class="text-center text-danger">'.$_SESSION['studentName'].' You\'re Not Allowed Here.</h2>
                </div>';
        }
        if(!isset($_SESSION['studentLogin']) && !isset($_SESSION['adminLogin'])){
            echo '<div class="container">
                    <img class="img-fluid" src="resource/img/noaccess.jpg" alt="No Access">
                </div>';
        }
    ?>
    <!-- Content Section End Here -->
    <!-- Footer Start -->
    <div class="user-select-none my-3">
        <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top bg-light">
            <div class="col-md-4 d-flex align-items-center">
                <a onclick="homePage()" class="mb-3 me-2 mb-md-0 text-muted lh-1 mx-5">
                    <img onMouseOver="this.style.cursor='pointer'" style="width: 130px" src="resource/img/navbaricon.png" alt="tabicon">
                </a>
                <span class="mb-3 mb-md-0 mx-4" style="font-weight: bold; font-size: 16px">©Exam(eON), By Soumalya&#127851;</span>
            </div>
        </footer>
    </div>
    <!-- Footer End -->
    <!-- Bootstrap js -->
    <script src="resource/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src= "resource/js/exameon.js"></script>
</body>

</html>