<?php
    echo 'Student Result';
?>